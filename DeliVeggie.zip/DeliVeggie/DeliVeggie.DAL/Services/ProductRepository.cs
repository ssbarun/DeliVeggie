﻿using DeliVeggie.DAL.Infrastructure;
using DeliVeggie.DAL.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DeliVeggie.DAL.Services
{
    public class ProductRepository : IProductRepository
    {
        private readonly DatabaseContext _dbContext;
        private readonly ILogger<ProductRepository> _logger;

        public ProductRepository(DatabaseContext dbContext, ILogger<ProductRepository> logger)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        /// <summary>
        /// Get list of products
        /// </summary>
        /// <returns></returns>
        public List<Product> GetProducts()
        {
            try
            {
                //Get list of products
                var products = _dbContext.Product.ToList();
                return products;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Product Service: Failed to get Product list: {ex}");
                return null;
            }
        }

        /// <summary>
        /// Get Product details by ProductId
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        public Product GetProductDetails(int productId)
        {
            try
            {
                //Get Product details by ProductId
                var productDetails = _dbContext.Product.Where(cc => cc.Id == productId).FirstOrDefault();
                return productDetails;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Product Service: Failed to get Product details: {ex}");
                return null;
            }
        }
    }
}
