﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DeliVeggie.DAL.Models
{
    public class ProductType
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [Column(TypeName = "varchar(25)")]
        public string Name { get; set; }

        [Required]
        [Column(TypeName = "varchar(100)")]
        public string Description { get; set; }
    }
}
