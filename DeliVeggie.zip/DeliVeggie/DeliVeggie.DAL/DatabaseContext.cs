﻿using DeliVeggie.DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace DeliVeggie.DAL
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options)
        {

        }

        public DbSet<ProductType> ProductType { get; set; }
        public DbSet<Product> Product { get; set; }
    }
}
