﻿using DeliVeggie.DAL.Models;
using System.Collections.Generic;

namespace DeliVeggie.DAL.Infrastructure
{
    public interface IProductRepository
    {
        public List<Product> GetProducts();
        public Product GetProductDetails(int productId);
    }
}
