﻿using DeliVeggie.DAL.Infrastructure;
using DeliVeggie.DAL.Models;
using DeliVeggie.ViewModel;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace DeliVeggie.Business.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;
        private readonly ILogger<ProductService> _logger;

        public ProductService(IProductRepository productRepository, ILogger<ProductService> logger)
        {
            _productRepository = productRepository;
            _logger = logger;
        }

        /// <summary>
        /// Get product list
        /// </summary>
        /// <returns></returns>
        public List<ProductVM> GetProducts()
        {
            List<ProductVM> productList = new List<ProductVM>();
            List<Product> products = _productRepository.GetProducts();
            foreach (Product product in products)
            {
                ProductVM productVM = new ProductVM();
                productVM.Id = product.Id;
                productVM.Name = product.Name;
                productVM.Description = product.Description;
                productVM.Price = product.Price;
                productList.Add(productVM);
            }
            return productList;
        }

        /// <summary>
        /// Get product details by product id
        /// </summary>
        /// <param name="productId">Product Id</param>
        /// <returns></returns>
        public ProductVM GetProductDetails(int productId)
        {
            Product product = _productRepository.GetProductDetails(productId);
            ProductVM productVM = new ProductVM() { Id = product.Id, Name = product.Name, Description = product.Description, Price = product.Price };
            return productVM;
        }
    }
}

