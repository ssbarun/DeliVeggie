﻿using DeliVeggie.ViewModel;
using System.Collections.Generic;

namespace DeliVeggie.Business.Services
{
    public interface IProductService
    {
        public List<ProductVM> GetProducts();
        public ProductVM GetProductDetails(int productId);
    }
}
