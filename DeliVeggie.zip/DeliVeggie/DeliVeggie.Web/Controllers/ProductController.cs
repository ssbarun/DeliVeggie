﻿using DeliVeggie.Business.Services;
using DeliVeggie.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;

namespace DeliVeggie.Web.Controllers
{
    public class ProductController : Controller
    {

        private readonly IProductService _productService;
        private readonly ILogger<ProductController> _logger;

        public ProductController(IProductService productService, ILogger<ProductController> logger)
        {
            _productService = productService;
            _logger = logger;
        }

        [Route("/Product/{id}")]
        public IActionResult Product(int id)
        {
            try
            {
                ProductVM product = new ProductVM();
                //Check for model validation errors
                if (ModelState.IsValid)
                {
                    //Get product details by product id
                    product = _productService.GetProductDetails(id);

                    //check products available or not
                    if (product != null)
                    {
                        return View(product);
                    }
                    else
                    {
                        return View();
                    }
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to get Product detail data: {ex}");
                return null;
            }
        }
    }
}
