﻿using DeliVeggie.Business.Services;
using DeliVeggie.ViewModel;
using DeliVeggie.Web.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace DeliVeggie.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly IProductService _productService;
        private readonly ILogger<HomeController> _logger;

        public HomeController(IProductService productService, ILogger<HomeController> logger)
        {
            _productService = productService;
            _logger = logger;
        }

        public IActionResult Index()
        {
            try
            {
                List<ProductVM> products = new List<ProductVM>();
                //Check for model validation errors
                if (ModelState.IsValid)
                {
                    //Get product data
                    products = _productService.GetProducts();

                    //check products available or not
                    if (products != null && products.Count > 0)
                    {
                        return View(products);
                    }
                    else
                    {
                        return View();
                    }
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to get Product list data: {ex}");
                return null;
            }           
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
