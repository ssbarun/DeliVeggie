USE [DeliVeggieDB]
GO

INSERT INTO [dbo].[ProductType]
           ([Name]
           ,[Description])
     VALUES
           ('General Insurance'
           ,'This offer coverage against the losses incurred other than the death of the policyholder.')
GO

INSERT INTO [dbo].[ProductType]
           ([Name]
           ,[Description])
     VALUES
           ('Life Insurance'
           ,'This offer coverage against unfortunate events like death or disability of the policyholder.')
GO

INSERT INTO [dbo].[Product]
           ([Name]
           ,[ProductTypeId]
           ,[Description]
           ,[Price])
     VALUES
           ('Health Insurance'
           ,1
           ,'Health Insurance Description'
           ,1000)
GO

INSERT INTO [dbo].[Product]
           ([Name]
           ,[ProductTypeId]
           ,[Description]
           ,[Price])
     VALUES
           ('Motor Insurance'
           ,1
           ,'Motor Insurance Description'
           ,2000)
GO

INSERT INTO [dbo].[Product]
           ([Name]
           ,[ProductTypeId]
           ,[Description]
           ,[Price])
     VALUES
           ('Home Insurance'
           ,1
           ,'Home Insurance Description'
           ,3000)
GO

INSERT INTO [dbo].[Product]
           ([Name]
           ,[ProductTypeId]
           ,[Description]
           ,[Price])
     VALUES
           ('Fire Insurance'
           ,1
           ,'Fire Insurance Description'
           ,4000)
GO

INSERT INTO [dbo].[Product]
           ([Name]
           ,[ProductTypeId]
           ,[Description]
           ,[Price])
     VALUES
           ('Travel Insurance'
           ,1
           ,'Travel Insurance Description'
           ,5000)
GO

INSERT INTO [dbo].[Product]
           ([Name]
           ,[ProductTypeId]
           ,[Description]
           ,[Price])
     VALUES
           ('Term Life Insurance'
           ,2
           ,'Term Life Insurance Description'
           ,6000)
GO

INSERT INTO [dbo].[Product]
           ([Name]
           ,[ProductTypeId]
           ,[Description]
           ,[Price])
     VALUES
           ('Unit-Linked Plans'
           ,2
           ,'Unit-Linked Plans Description'
           ,7000)
GO

INSERT INTO [dbo].[Product]
           ([Name]
           ,[ProductTypeId]
           ,[Description]
           ,[Price])
     VALUES
           ('Endowment Plans'
           ,2
           ,'Endowment Plans Description'
           ,8000)
GO

INSERT INTO [dbo].[Product]
           ([Name]
           ,[ProductTypeId]
           ,[Description]
           ,[Price])
     VALUES
           ('Child Plans'
           ,2
           ,'Child Plans Description'
           ,9000)
GO

INSERT INTO [dbo].[Product]
           ([Name]
           ,[ProductTypeId]
           ,[Description]
           ,[Price])
     VALUES
           ('Pension Plans'
           ,2
           ,'Pension Plans Description'
           ,10000)
GO

