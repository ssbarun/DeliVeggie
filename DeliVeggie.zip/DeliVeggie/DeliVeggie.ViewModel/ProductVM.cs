﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace DeliVeggie.ViewModel
{
    public class ProductVM
    {
        public int Id { get; set; }

        [Required]
        [DisplayName("Product Name")]
        [MaxLength(25)]
        public string Name { get; set; }

        [Required]
        [DisplayName("Product Description")]
        [MaxLength(25)]
        public string Description { get; set; }
       

        [Required]
        [Range(0, 99999.99, ErrorMessage = "Invalid Price; Max 5 digits")]
        [DisplayName("Product Price")]
        public decimal Price { get; set; }

        public ProductTypeVM ProductType { get; set; }
    }
}
