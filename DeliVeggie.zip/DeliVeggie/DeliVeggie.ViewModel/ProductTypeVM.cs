﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace DeliVeggie.ViewModel
{
    public class ProductTypeVM
    {
        public int Id { get; set; }

        [Required]
        [DisplayName("Product Type Name")]
        [MaxLength(25)]
        public string Name { get; set; }

        [Required]
        [DisplayName("Product Type Description")]
        [MaxLength(25)]
        public string Description { get; set; }
    }
}
